package org.example.springsecurity;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldController {

    // 受保护的 API
    @GetMapping("/hello")
    public String helloWorld() {
        return "Hello World";
    }

    // 公开的登录 API
    @GetMapping("/login")
    public String login() {
        return "请使用正确的用户名和密码进行身份验证。";
    }
}